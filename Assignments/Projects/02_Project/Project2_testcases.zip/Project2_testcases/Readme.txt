testcases.txt contains the test case grammars (and their solutions) when running the commands given in commands.txt
	For updateAssocList:
		The order of the elements in the corresponding list of the symbol does not matter.
			'((a (10 9 1 2))) is just as correct as '((a (1 2 9 10))).
	For the rules output:
		If the rule itself was not a list, I still gave you full points.
		For example, if in grammar0, your rules output was:
			'((start a))
		That is still correct.

commands.txt gives the autograder commands that was used to grade your proj2.ss file.
	getPredictSets required a "NTs" input after rules. 
		If you deleted that input before you handed it in, it was added back to your proj2.ss before grading.
